
// parikshat's edit

var drawer = function () {
    if (!Element.prototype.closest) {
      if (!Element.prototype.matches) {
        Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector;
      }
      Element.prototype.closest = function (s) {
        var el = this;
        var ancestor = this;
        if (!document.documentElement.contains(el)) return null;
        do {
          if (ancestor.matches(s)) return ancestor;
          ancestor = ancestor.parentElement;
        } while (ancestor !== null);
        return null;
      };  
    }
    var settings = {
      speedOpen: 50,
      speedClose: 350,
      activeClass: 'is-active',
      visibleClass: 'is-visible',
      selectorTarget: '[data-drawer-target]',
      selectorTrigger: '[data-drawer-trigger]',
      selectorClose: '[data-drawer-close]',

    };


    var toggleccessibility = function (event) {
      if (event.getAttribute('aria-expanded') === 'true') {
        event.setAttribute('aria-expanded', false);
      } else {
        event.setAttribute('aria-expanded', true);
      }
    };


    var openDrawer = function (trigger) {
      var target = document.getElementById(trigger.getAttribute('aria-controls'));
      target.classList.add(settings.activeClass);
      document.documentElement.style.overflow = 'hidden';
      toggleccessibility(trigger);


      setTimeout(function () {
        target.classList.add(settings.visibleClass);
      }, settings.speedOpen);
    };

    var closeDrawer = function (event) {
      var closestParent = event.closest(settings.selectorTarget),
        childrenTrigger = document.querySelector('[aria-controls="' + closestParent.id + '"');
      closestParent.classList.remove(settings.visibleClass);
      document.documentElement.style.overflow = '';
      toggleccessibility(childrenTrigger);
      setTimeout(function () {
        closestParent.classList.remove(settings.activeClass);
      }, settings.speedClose);
    };
    var clickHandler = function (event) {
      var toggle = event.target,
        open = toggle.closest(settings.selectorTrigger),
        close = toggle.closest(settings.selectorClose);


      if (open) { openDrawer(open); }
      if (close) { closeDrawer(close); }
      if (open || close) { event.preventDefault(); }
    };


    var keydownHandler = function (event) {
      if (event.key === 'Escape' || event.keyCode === 27) {
        var drawers = document.querySelectorAll(settings.selectorTarget),
          i;
        for (i = 0; i < drawers.length; ++i) {
          if (drawers[i].classList.contains(settings.activeClass)) {
            closeDrawer(drawers[i]);
          }
        }
      }
    };

    document.addEventListener('click', clickHandler, false);
    document.addEventListener('keydown', keydownHandler, false);
};

drawer();



// function to update cart drawe subtotal and count


function updatedrawer(data){
  
//   console.log(data);
 var quantity = data.item_count;

 
 var totalprice = data.items_subtotal_price/100;
  var totaldis = data.total_discount/100;
  
  
  $(".cart-count-bubble span:first-child").text(quantity);
  $(".cart__total_price").text( totalprice);
  $(".total_savings .ammount").text(totaldis);
}

// function to add lineitem
var minussym = '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" role="presentation" class="icon icon-minus" fill="none" viewBox="0 0 10 2"><path fill-rule="evenodd" clip-rule="evenodd" d="M.5 1C.5.7.7.5 1 .5h8a.5.5 0 110 1H1A.5.5 0 01.5 1z" fill="currentColor"></svg>';
var plussym  = '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" role="presentation" class="icon icon-plus" fill="none" viewBox="0 0 10 10"><path fill-rule="evenodd" clip-rule="evenodd" d="M1 4.51a.5.5 0 000 1h3.5l.01 3.5a.5.5 0 001-.01V5.5l3.5-.01a.5.5 0 00-.01-1H5.5L5.49.99a.5.5 0 00-1 .01v3.5l-3.5.01H1z" fill="currentColor"></svg>'


function updatelineitem(data){

//   console.log(data);
  var currsym = $("#drawwr_wrapper").attr("data-curr");
  var delsym = $("#drawwr_wrapper").attr("data-del");
  var count = data.items.length;
  var itemdt = data.items;
  
  if(count>0){
  
    var i;
  for(i=0 ; i<count ; i++){
 
    var n = itemdt[i];
    var fp = n.final_price;
    var op = n.original_price;
    $(".cart_items_inner_wrapper").append('<div class="drawer_item is_ajax" data-index="'+i+'" data-id="'+n.id+'"> <div class="item_inner" data-quan=""> <div class="item_wrap_img"> <a href="'+ n.url +'">  <img src="'+n.image+'"> </a> </div> <div class="item_wrap_content">  <div class="item_wrap_content_up"> <a href="'+ n.url +'"> <h4> '+ n.title +' </h4></a><img class="del_btn" src="'+delsym+'">   </div> <div class="item_wrap_content_down"> <div class="quan_selector"> <span data-btn="minus"> '+minussym+' </span> <input type="text" readonly min=1 value="'+n.quantity+'"> <span data-btn="plus"> '+plussym+' </span> </div> <div class="price_field"> <p class="a"> <span class="aa">'+ currsym+ ' ' + n.original_price/100 + ' </span> '+ currsym + ' ' + n.final_price/100  +'   </p> <p class="b"> You save '+ currsym +  ' ' + (n.original_price - n.final_price)/100 + '</p>  </div>  </div> </div>  </div> </div>');
    if(fp == op){
      $(".cart_items_inner_wrapper .aa,.cart_items_inner_wrapper .b ").addClass("hide_line");
      $(".cart_items_inner_wrapper .a").addClass("provide_padding");
    
    }
        
    
  }
  

}
}

// check if cart is empty or not

function cartcheck(data){

  var x = data.items.length;
  
  if(x==0){
  
    $(".cart_items_inner_wrapper , .total_price_wrap").css("display","none");
    $(".empty-cart-msg").css("display","block");
  
  }
  else{
  
   $(".cart_items_inner_wrapper , .total_price_wrap").css("display","block");
    $(".empty-cart-msg").css("display","none");
  }

}

// edit for quantity btn

$("body").on("click",".quan_selector span" , function(){
  var x = $(this).attr("data-btn");
  var inp = $(this).parent().find("input");
  var val = $(inp).val();

  if(x=="plus" && parseInt(val ) >= 0){ 
     var nval = parseInt(val ) + 1;
  }
   else if(x=="minus" && parseInt(val ) >= 0){
     var nval = parseInt(val ) - 1;
  }
  var id = $(this).parents(".drawer_item").attr("data-id"); 
  if(nval > 0  ){
   $.ajax({
          type: 'POST',
          url: '/cart/change?id='+id+'&amp;quantity='+nval,
          dataType: 'json',
          success: function(itemData) {
    							 inp.val(nval);
     							 inp.change();
            					 updatedrawer(itemData);
          }
 		  });
  
  } else {
     inp.val(nval);
     inp.change();
    $(this).parents('.drawer_item').find('.del_btn').click();
  }
  

  
});



// edit for del  btn

$("body").on("click" , ".new_cart_drawer .del_btn",function(){

  var id = $(this).parents(".drawer_item").attr("data-id");
  var item = $(this).parents(".drawer_item");
   $.ajax({
          type: 'POST',
          url: '/cart/change?id='+id+'&amp;quantity=0',
          dataType: 'json',
     success: function(itemData) {

       
       item.remove();
       
       updatedrawer(itemData);
       cartcheck(itemData);
     
     }
   
   
   });
            

});



// to add line item
 $("body").on("click",".product-form__submit.button",function(){
  
  
   
   setTimeout(function(){ $.ajax({
          type: 'GET',
          url: '/cart.js',
          dataType: 'json',
     success: function(itemData) {
     

       
     $(".drawer_item").remove();
       updatelineitem(itemData);
       updatedrawer(itemData);
       cartcheck(itemData);
       $("header__icon.header__icon--cart").attr("aria-expanded",true);
   $(".new_cart_drawer").addClass("is-active is-visible");
       $("html").css("overflow","hidden");
     
     }
   
   
   });
                        },2000);
   
  
  });

// function to close drawer if clicked outside
  $(document).mouseup(function(e) 
{
    var container = $(".new_cart_drawer");

    // if the target of the click isn't the container nor a descendant of the container
    
    if(container.hasClass("is-active")){
      
    
    if (!container.is(e.target) && container.has(e.target).length === 0) 
    {
     $(".drawer__title .goback_link").click();
    }
    
    }
}); 
  


//final  edit end

$("#cart-icon-bubble").on("click", function(){
setTimeout(function(){
   var windowHeight = $(window).height();
   var drawer_foot_area = $(".total_price_wrap").height();
   var setpxItemDrawar1 = windowHeight - drawer_foot_area;
   var setpxItemDrawar = setpxItemDrawar1 - 150;
$("#cart__drawer_items").css("maxHeight",setpxItemDrawar); 
}, 800); 
});

$("body").on("click","button.product-form__submit", function(){
setTimeout(function(){
   var windowHeight = $(window).height();
   var drawer_foot_area = $(".total_price_wrap").height();
   var setpxItemDrawar1 = windowHeight - drawer_foot_area;
   var setpxItemDrawar = setpxItemDrawar1 - 100;
$("#cart__drawer_items").css("maxHeight",setpxItemDrawar); 
}, 4000);
});



 



